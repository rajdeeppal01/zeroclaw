==================================================
ZeroClaw Beta Access - Windows Endpoint Agent
Prepared for: user2
==================================================

Welcome to the ZeroClaw Threat Intelligence Beta!

This folder contains your unique, cryptographically secure mTLS 
certificates that grant you access to the live ZeroClaw Hub.

HOW TO ACTIVATE YOUR PROTECTION:
1. Install Python (if you don't have it): https://www.python.org/downloads/
2. Open your Windows Start Menu, type "PowerShell", right-click it, 
   and select "Run as Administrator".
3. Use the `cd` command to navigate to the folder where you extracted these files.
4. Run this command to install the required network library:
   pip install requests
5. Start the agent:
   python windows_agent.py

Your laptop is now actively syncing with the ZeroClaw B2B Threat Intelligence Hub 
and automatically locking down your Windows Defender Firewall against live threats!
